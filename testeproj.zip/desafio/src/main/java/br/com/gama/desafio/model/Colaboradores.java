package br.com.gama.desafio.model;

		import java.util.List;

		import javax.persistence.CascadeType;
		import javax.persistence.Column;
		import javax.persistence.Entity;
		import javax.persistence.GeneratedValue;
		import javax.persistence.GenerationType;
		import javax.persistence.Id;
		import javax.persistence.ManyToOne;
		import javax.persistence.OneToMany;
		import javax.persistence.Table;


		import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


		@Entity
		@Table(name="TBL_DESAFIO_COLABORADORES")
		public class Colaboradores {


		    @Column(name="IdColab")
		    @Id
		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    private int idColaboradores;
		    
		    @Column(name="RACF")
		    private int racf;
		    
		    @Column(name="NOME", length=100)
		    private String nomeColab;
		    
		    // Cardinalidade Colab -> Departamento (ManytoOne)
		    @JsonIgnoreProperties("colaboradores")
		    @ManyToOne
		    private Departamentos departamentos;
		    
		    // Cardinalidade Colab -> Historico
		    @JsonIgnoreProperties("colaborador")
		    @OneToMany(cascade=CascadeType.ALL , mappedBy="colaborador")
		    private List<Historicos> historicos;
		        
		    @Column(name="EMAIL", length=100)
		    private String email;
		    
		    @Column(name="SENHA", length=15)
		    private String senha;
		    
		    @Column(name="NUMEQUIPAMENTO")
		    private int numEquip;
		    
		    @Column(name="DESCEQUIPAMENTO", length=100)
		    private String descEquip;
		    
		    @Column(name="NUMCONECTREDE", length=100)
		    private String numConectRede;
		    
		    @Column(name="FOTO", length=100)
		    private String foto;

			public int getIdColaboradores() {
				return idColaboradores;
			}

			public void setIdColaboradores(int idColaboradores) {
				this.idColaboradores = idColaboradores;
			}

			public int getRacf() {
				return racf;
			}

			public void setRacf(int racf) {
				this.racf = racf;
			}

			public String getNomeColab() {
				return nomeColab;
			}

			public void setNomeColab(String nomeColab) {
				this.nomeColab = nomeColab;
			}

			public Departamentos getDepartamentos() {
				return departamentos;
			}

			public void setDepartamentos(Departamentos departamentos) {
				this.departamentos = departamentos;
			}

			public List<Historicos> getHistoricos() {
				return historicos;
			}

			public void setHistoricos(List<Historicos> historicos) {
				this.historicos = historicos;
			}

			public String getEmail() {
				return email;
			}

			public void setEmail(String email) {
				this.email = email;
			}

			public String getSenha() {
				return senha;
			}

			public void setSenha(String senha) {
				this.senha = senha;
			}

			public int getNumEquip() {
				return numEquip;
			}

			public void setNumEquip(int numEquip) {
				this.numEquip = numEquip;
			}

			public String getDescEquip() {
				return descEquip;
			}

			public void setDescEquip(String descEquip) {
				this.descEquip = descEquip;
			}

			public String getNumConectRede() {
				return numConectRede;
			}

			public void setNumConectRede(String numConectRede) {
				this.numConectRede = numConectRede;
			}

			public String getFoto() {
				return foto;
			}

			public void setFoto(String foto) {
				this.foto = foto;
			}

			public Colaboradores(int idColaboradores, int racf, String nomeColab, Departamentos departamentos,
					List<Historicos> historicos, String email, String senha, int numEquip, String descEquip,
					String numConectRede, String foto) {
				super();
				this.idColaboradores = idColaboradores;
				this.racf = racf;
				this.nomeColab = nomeColab;
				this.departamentos = departamentos;
				this.historicos = historicos;
				this.email = email;
				this.senha = senha;
				this.numEquip = numEquip;
				this.descEquip = descEquip;
				this.numConectRede = numConectRede;
				this.foto = foto;
			}

			public Colaboradores() {
				super();
			}
		    
		   


		}
