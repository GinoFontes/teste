package br.com.gama.desafio.dao;

import org.springframework.data.repository.CrudRepository;

import br.com.gama.desafio.model.Historicos;

public interface HistoricosDAO extends CrudRepository <Historicos, Integer> {

		
		
}
	
	
	

