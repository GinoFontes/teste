package br.com.gama.desafio.model;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

 
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="TBL_DESAFIO_DEPARTAMENTOS")
public class Departamentos {
    
        @Column(name="IdDEPART")
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int idDepart;
        
        @Column(name="NOME", length=30)
        private String nomeDepart;
        
        @Column(name="VLAN", length=50)
        private String nomeVlan;
        
        @Column(name="REDE", length=50)
        private String rede;
        
        // Cardinalidade Departamento -> Colab (OneToMany)
        @JsonIgnoreProperties("departamentos")
        @OneToMany(cascade=CascadeType.ALL , mappedBy="departamentos")
        private List<Colaboradores> colaboradores;
        
        
        // Cardinalidade Departamento -> Historico (OneToMany)
        @JsonIgnoreProperties("departamentos")
        @OneToMany(cascade=CascadeType.ALL , mappedBy="departamentos")
        private List<Historicos> historicos;


		public int getIdDepart() {
			return idDepart;
		}


		public void setIdDepart(int idDepart) {
			this.idDepart = idDepart;
		}


		public String getNomeDepart() {
			return nomeDepart;
		}


		public void setNomeDepart(String nomeDepart) {
			this.nomeDepart = nomeDepart;
		}


		public String getNomeVlan() {
			return nomeVlan;
		}


		public void setNomeVlan(String nomeVlan) {
			this.nomeVlan = nomeVlan;
		}


		public String getRede() {
			return rede;
		}


		public void setRede(String rede) {
			this.rede = rede;
		}


		public List<Colaboradores> getColaboradores() {
			return colaboradores;
		}


		public void setColaboradores(List<Colaboradores> colaboradores) {
			this.colaboradores = colaboradores;
		}


		public List<Historicos> getHistoricos() {
			return historicos;
		}


		public void setHistoricos(List<Historicos> historicos) {
			this.historicos = historicos;
		}


		public Departamentos(int idDepart, String nomeDepart, String nomeVlan, String rede,
				List<Colaboradores> colaboradores, List<Historicos> historicos) {
			super();
			this.idDepart = idDepart;
			this.nomeDepart = nomeDepart;
			this.nomeVlan = nomeVlan;
			this.rede = rede;
			this.colaboradores = colaboradores;
			this.historicos = historicos;
		}


		public Departamentos() {
			super();
		}
        
        
        
}