package br.com.gama.desafio.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import br.com.gama.desafio.model.Departamentos;


public interface DepartamentosDAO extends CrudRepository<Departamentos, Integer> {
	    public List<Departamentos> findByDepartamentos(String nomeDepartamentos);
	}	
	

