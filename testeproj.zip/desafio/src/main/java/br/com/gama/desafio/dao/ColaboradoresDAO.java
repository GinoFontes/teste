package br.com.gama.desafio.dao;

import org.springframework.data.repository.CrudRepository;

import br.com.gama.desafio.model.Colaboradores;

public interface ColaboradoresDAO extends CrudRepository<Colaboradores, Integer> {
    public Colaboradores findByEmailAndSenha(String email, String senha);
}


